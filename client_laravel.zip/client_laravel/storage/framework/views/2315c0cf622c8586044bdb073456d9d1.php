<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Client Side</title>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    </head>
    <body class="antialiased">
        <div class="container">
            <div class="row chat-row" style="margin: 30px">
                <div class="chat-section">
                    <div class="chat-box mb-3">
                        <input type="text" style="border: 1px solid black;" class="form-control" id="chatInput" style="width: auto;" placeholder="Message">
                    </div>
                </div>

                <div>
                    <ul id="messages"></ul>
                </div>
            </div>
        </div>
    </body>
    <script src="https://cdn.socket.io/4.6.0/socket.io.min.js" integrity="sha384-c79GN5VsunZvi+Q/WObgk2in0CbZsHnjEqvFxC5DxHn9lTfNce2WW6h2pH6u/kF+" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script>
        $(function() {
            let ip_address = "127.0.0.1";
            let socket_port = "3000";
            let socket = io(ip_address +':'+ socket_port);

            var messages = document.getElementById('messages');
            let chatInput = $('#chatInput');

            chatInput.keypress(function(e) {
                let message = $(this).val();

                if(e.which == 13) {
                    socket.emit('chat', message);
                    $('#chatInput').val("");
                }
            });

            socket.on("user-connect", () => {
                const newItem = document.createElement("li");
                newItem.innerText = "User Connected.";
                messages.appendChild(newItem);
                window.scrollTo(0, document.body.scrollHeight);
            });

            socket.on("user-disconnect", () => {
                const newItem = document.createElement("li");
                newItem.innerText = "User Disconnected.";
                messages.appendChild(newItem);
                window.scrollTo(0, document.body.scrollHeight);
            });

            socket.on('chat-message', function (msg) {
                var item = document.createElement('li');
                item.textContent = msg;
                messages.appendChild(item);
                window.scrollTo(0, document.body.scrollHeight);
            });
        });
    </script>
</html><?php /**PATH C:\Users\Mark-PC\Downloads\socket-chat\client_laravel\resources\views/welcome.blade.php ENDPATH**/ ?>